import React, { useState, useCallback } from 'react';
import Display from './components/Display';
import ButtonGrid from './components/ButtonGrid';
import { ButtonAction, Operator } from './types';

const App: React.FC = () => {
    const [displayValue, setDisplayValue] = useState<string>('0');
    const [firstOperand, setFirstOperand] = useState<number | null>(null);
    const [operator, setOperator] = useState<Operator | null>(null);
    const [waitingForSecondOperand, setWaitingForSecondOperand] = useState<boolean>(false);
    const [expression, setExpression] = useState<string>('');
    const [isResultShown, setIsResultShown] = useState<boolean>(false);

    const getOperatorSymbol = (op: Operator): string => {
        switch (op) {
            case Operator.Add: return '+';
            case Operator.Subtract: return '−';
            case Operator.Multiply: return '×';
            case Operator.Divide: return '÷';
            default: return '';
        }
    };

    const performCalculation = useCallback((): number | 'Błąd' => {
        if (operator === null || firstOperand === null) return parseFloat(displayValue);
        
        const secondOperand = parseFloat(displayValue);

        if (operator === Operator.Add) return firstOperand + secondOperand;
        if (operator === Operator.Subtract) return firstOperand - secondOperand;
        if (operator === Operator.Multiply) return firstOperand * secondOperand;
        if (operator === Operator.Divide) {
            if (secondOperand === 0) return 'Błąd';
            return firstOperand / secondOperand;
        }
        return secondOperand;
    }, [operator, firstOperand, displayValue]);

    const handleButtonClick = useCallback((action: ButtonAction, value?: string) => {
        switch (action) {
            case ButtonAction.Number:
                if (value === undefined) return;
                if (isResultShown) {
                    setDisplayValue(value);
                    setExpression('');
                    setIsResultShown(false);
                } else if (waitingForSecondOperand) {
                    setDisplayValue(value);
                    setWaitingForSecondOperand(false);
                } else {
                    setDisplayValue(displayValue === '0' ? value : displayValue + value);
                }
                break;

            case ButtonAction.Decimal:
                if (isResultShown) {
                    setDisplayValue('0.');
                    setExpression('');
                    setIsResultShown(false);
                    return;
                }
                if (waitingForSecondOperand) {
                    setDisplayValue('0.');
                    setWaitingForSecondOperand(false);
                    return;
                }
                if (!displayValue.includes('.')) {
                    setDisplayValue(displayValue + '.');
                }
                break;

            case ButtonAction.Operator:
                if (value === undefined || !Object.values(Operator).includes(value as Operator)) return;
                const nextOperator = value as Operator;
                const inputValue = parseFloat(displayValue);

                if (operator && waitingForSecondOperand) {
                    setOperator(nextOperator);
                    if (firstOperand !== null) {
                       setExpression(`${parseFloat(firstOperand.toFixed(7))} ${getOperatorSymbol(nextOperator)}`);
                    }
                    return;
                }

                let newFirstOperand: number;
                if (firstOperand === null) {
                    newFirstOperand = inputValue;
                    setFirstOperand(inputValue);
                } else if (operator) {
                    const result = performCalculation();
                    if (result === 'Błąd') {
                         setDisplayValue('Błąd');
                         setExpression('Błąd');
                         setFirstOperand(null);
                         setOperator(null);
                         setWaitingForSecondOperand(false);
                         setIsResultShown(true);
                         return;
                    }
                    const resultString = `${parseFloat(result.toFixed(7))}`;
                    setDisplayValue(resultString);
                    newFirstOperand = result;
                    setFirstOperand(result);
                } else {
                    newFirstOperand = inputValue;
                }
                
                setWaitingForSecondOperand(true);
                setOperator(nextOperator);
                setIsResultShown(false);
                setExpression(`${parseFloat(newFirstOperand.toFixed(7))} ${getOperatorSymbol(nextOperator)}`);
                break;

            case ButtonAction.Calculate:
                if (operator === null || firstOperand === null || waitingForSecondOperand) return;
                const secondOperand = parseFloat(displayValue);
                const result = performCalculation();

                const fullExpression = `${firstOperand} ${getOperatorSymbol(operator)} ${secondOperand} =`;
                // FIX: Property 'replaceAll' does not exist on type 'string'. Replaced with .replace() and a global regex.
                setExpression(fullExpression.replace(/\./g, ','));

                if (result === 'Błąd') {
                    setDisplayValue('Błąd');
                } else {
                    setDisplayValue(`${parseFloat(result.toFixed(7))}`);
                }
                setFirstOperand(null);
                setOperator(null);
                setWaitingForSecondOperand(false);
                setIsResultShown(true);
                break;

            case ButtonAction.Clear:
                setDisplayValue('0');
                setFirstOperand(null);
                setOperator(null);
                setWaitingForSecondOperand(false);
                setExpression('');
                setIsResultShown(false);
                break;
        }
    }, [displayValue, firstOperand, operator, waitingForSecondOperand, isResultShown, performCalculation]);

    return (
        <div className="flex items-center justify-center min-h-screen text-white">
            <div className="w-full max-w-sm mx-auto bg-gray-800 rounded-2xl shadow-2xl p-6 border-4 border-gray-700">
                <header className="mb-6 text-center">
                    <h1 className="text-3xl font-bold text-teal-400">Matemax.app</h1>
                    <p className="text-gray-400 text-sm">React Calculator</p>
                </header>
                <Display value={displayValue} expression={expression} />
                <ButtonGrid onButtonClick={handleButtonClick} />
            </div>
        </div>
    );
};

export default App;