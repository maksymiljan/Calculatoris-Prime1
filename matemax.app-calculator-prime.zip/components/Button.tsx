import React from 'react';

interface ButtonProps {
  label: string;
  onClick: () => void;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ label, onClick, className = '' }) => {
  const baseClasses = "rounded-xl h-20 text-3xl font-medium focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-opacity-50 transition-all duration-150 ease-in-out transform active:scale-95 active:shadow-inner";
  
  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${className}`}
    >
      {label}
    </button>
  );
};

export default Button;
