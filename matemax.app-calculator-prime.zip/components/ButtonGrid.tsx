import React from 'react';
import Button from './Button';
import { ButtonAction, Operator } from '../types';

interface ButtonGridProps {
  onButtonClick: (action: ButtonAction, value?: string) => void;
}

const ButtonGrid: React.FC<ButtonGridProps> = ({ onButtonClick }) => {
    return (
        <div className="grid grid-cols-4 gap-4">
            {/* Row 1 */}
            <Button label="C" onClick={() => onButtonClick(ButtonAction.Clear)} className="bg-gray-600 hover:bg-gray-700 text-white" />
            <Button label="÷" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Divide)} className="bg-teal-600 hover:bg-teal-700 text-white" />
            <Button label="×" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Multiply)} className="bg-teal-600 hover:bg-teal-700 text-white" />
            <Button label="−" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Subtract)} className="bg-teal-600 hover:bg-teal-700 text-white" />

            {/* Row 2 */}
            <Button label="7" onClick={() => onButtonClick(ButtonAction.Number, '7')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="8" onClick={() => onButtonClick(ButtonAction.Number, '8')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="9" onClick={() => onButtonClick(ButtonAction.Number, '9')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="+" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Add)} className="bg-teal-600 hover:bg-teal-700 text-white" />

            {/* Row 3 */}
            <Button label="4" onClick={() => onButtonClick(ButtonAction.Number, '4')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="5" onClick={() => onButtonClick(ButtonAction.Number, '5')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="6" onClick={() => onButtonClick(ButtonAction.Number, '6')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            
            <Button label="=" onClick={() => onButtonClick(ButtonAction.Calculate)} className="bg-orange-500 hover:bg-orange-600 text-white row-span-2" />

            {/* Row 4 */}
            <Button label="1" onClick={() => onButtonClick(ButtonAction.Number, '1')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="2" onClick={() => onButtonClick(ButtonAction.Number, '2')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            <Button label="3" onClick={() => onButtonClick(ButtonAction.Number, '3')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
            
            {/* Row 5 */}
            <Button label="0" onClick={() => onButtonClick(ButtonAction.Number, '0')} className="bg-gray-700 hover:bg-gray-600 text-gray-200 col-span-2" />
            <Button label="." onClick={() => onButtonClick(ButtonAction.Decimal, '.')} className="bg-gray-700 hover:bg-gray-600 text-gray-200" />
        </div>
    );
};

export default ButtonGrid;
