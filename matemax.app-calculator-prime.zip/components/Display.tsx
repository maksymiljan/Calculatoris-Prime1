import React from 'react';

interface DisplayProps {
  value: string;
  expression: string;
}

const Display: React.FC<DisplayProps> = ({ value, expression }) => {
  const formattedValue = value.replace('.', ',');
  // FIX: Property 'replaceAll' does not exist on type 'string'. Replaced with .replace() and a global regex.
  const formattedExpression = expression.replace(/\./g, ',');
  const textSizeClass = value.length > 9 ? 'text-4xl' : 'text-5xl';

  return (
    <div className="bg-gray-900 rounded-lg p-4 text-right break-words mb-6 min-h-[6rem] flex flex-col items-end justify-end overflow-hidden">
      <div className="w-full text-xl text-gray-400 font-mono truncate h-8 flex items-center justify-end" title={formattedExpression}>
        <span>{formattedExpression}</span>
      </div>
      <div className={`w-full font-mono transition-font-size duration-200 ${textSizeClass}`}>
        {formattedValue}
      </div>
    </div>
  );
};

export default Display;