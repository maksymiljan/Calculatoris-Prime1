
export enum Operator {
  Add = '+',
  Subtract = '-',
  Multiply = '*',
  Divide = '/',
}

export enum ButtonAction {
  Number = 'number',
  Operator = 'operator',
  Decimal = 'decimal',
  Clear = 'clear',
  Calculate = 'calculate',
}
