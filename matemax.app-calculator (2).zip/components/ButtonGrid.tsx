import React from 'react';
import Button from './Button';
import { ButtonAction, Operator } from '../types';

interface ButtonGridProps {
  onButtonClick: (action: ButtonAction, value?: string) => void;
}

const ButtonGrid: React.FC<ButtonGridProps> = ({ onButtonClick }) => {
    const operatorClasses = "bg-teal-600 hover:bg-teal-700 text-white";
    const numberClasses = "bg-gray-700 hover:bg-gray-600 text-gray-200";
    const specialClasses = "bg-gray-600 hover:bg-gray-700 text-white";

    return (
        <div className="grid grid-cols-4 gap-4">
            {/* Row 1 */}
            <Button label="AC" onClick={() => onButtonClick(ButtonAction.AllClear)} className={specialClasses} />
            <Button label="(" onClick={() => onButtonClick(ButtonAction.Parenthesis, '(')} className={specialClasses} />
            <Button label=")" onClick={() => onButtonClick(ButtonAction.Parenthesis, ')')} className={specialClasses} />
            <Button label="DEL" onClick={() => onButtonClick(ButtonAction.Backspace)}  className={specialClasses}  style={{ backgroundColor: '#dc3545', color: 'white', borderColor: '#dc3545' }}/>

            {/* Row 2 */}
            <Button label="7" onClick={() => onButtonClick(ButtonAction.Number, '7')} className={numberClasses} />
            <Button label="8" onClick={() => onButtonClick(ButtonAction.Number, '8')} className={numberClasses} />
            <Button label="9" onClick={() => onButtonClick(ButtonAction.Number, '9')} className={numberClasses} />
            <Button label="÷" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Divide)} className={operatorClasses} />
            
            {/* Row 3 */}
            <Button label="4" onClick={() => onButtonClick(ButtonAction.Number, '4')} className={numberClasses} />
            <Button label="5" onClick={() => onButtonClick(ButtonAction.Number, '5')} className={numberClasses} />
            <Button label="6" onClick={() => onButtonClick(ButtonAction.Number, '6')} className={numberClasses} />
            <Button label="×" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Multiply)} className={operatorClasses} />

            {/* Row 4 */}
            <Button label="1" onClick={() => onButtonClick(ButtonAction.Number, '1')} className={numberClasses} />
            <Button label="2" onClick={() => onButtonClick(ButtonAction.Number, '2')} className={numberClasses} />
            <Button label="3" onClick={() => onButtonClick(ButtonAction.Number, '3')} className={numberClasses} />
            <Button label="−" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Subtract)} className={operatorClasses} />
            
            {/* Row 5 */}
            <Button label="0" onClick={() => onButtonClick(ButtonAction.Number, '0')} className={`${numberClasses} col-span-2`} />
            <Button label="." onClick={() => onButtonClick(ButtonAction.Decimal, '.')} className={numberClasses} />
            <Button label="=" onClick={() => onButtonClick(ButtonAction.Calculate)} className="bg-orange-500 hover:bg-orange-600 text-white" />
            <Button label="+" onClick={() => onButtonClick(ButtonAction.Operator, Operator.Add)} className={`${operatorClasses} -order-1`} />
        </div>
    );
};

export default ButtonGrid;
