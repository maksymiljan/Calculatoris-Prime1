import React from 'react';

interface ButtonProps {
  label: string;
  onClick: () => void;
  className?: string;
  style?: React.CSSProperties; // 1. Dodajemy opcjonalną właściwość style
}

const Button: React.FC<ButtonProps> = ({ label, onClick, className = '', style }) => { // 2. Odbieramy `style`
  const baseClasses = "rounded-xl h-20 text-3xl font-medium focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-opacity-50 transition-all duration-150 ease-in-out transform active:scale-95 active:shadow-inner";
  
  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${className}`}
      style={style} // 3. Przekazujemy `style` do właściwego elementu HTML
    >
      {label}
    </button>
  );
};

export default Button;