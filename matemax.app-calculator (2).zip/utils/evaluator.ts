// A safe expression evaluator using Shunting-yard algorithm
// It handles parentheses and order of operations.

const precedence: { [key: string]: number } = {
  '+': 1,
  '−': 1,
  '×': 2,
  '÷': 2,
};

const isOperator = (token: string): boolean => {
  return token in precedence;
};

const applyOp = (operator: string, b: number, a: number): number => {
  switch (operator) {
    case '+': return a + b;
    case '−': return a - b;
    case '×': return a * b;
    case '÷':
      if (b === 0) {
        throw new Error("Division by zero");
      }
      return a / b;
    default:
      throw new Error("Invalid operator");
  }
};

export const evaluate = (expression: string): string => {
  try {
    // 1. Tokenize the expression
    // Replace Polish operators for internal consistency
    const standardizedExpr = expression.replace(/,/g, '.');
    const tokens = standardizedExpr.split(/(\s+[+\-−×÷]\s+|\(|\))/).filter(t => t && t.trim() !== '').map(t => t.trim());

    const values: number[] = [];
    const ops: string[] = [];

    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i];

      if (!isNaN(parseFloat(token))) {
        values.push(parseFloat(token));
      } else if (token === '(') {
        ops.push(token);
      } else if (token === ')') {
        while (ops.length > 0 && ops[ops.length - 1] !== '(') {
          const op = ops.pop();
          const val2 = values.pop();
          const val1 = values.pop();
          if (op === undefined || val1 === undefined || val2 === undefined) {
             throw new Error("Invalid expression");
          }
          values.push(applyOp(op, val2, val1));
        }
        if (ops.length === 0) throw new Error("Mismatched parentheses");
        ops.pop(); // Pop '('
      } else if (isOperator(token)) {
        while (
          ops.length > 0 &&
          isOperator(ops[ops.length - 1]) &&
          precedence[ops[ops.length - 1]] >= precedence[token]
        ) {
          const op = ops.pop();
          const val2 = values.pop();
          const val1 = values.pop();
          if (op === undefined || val1 === undefined || val2 === undefined) {
             throw new Error("Invalid expression");
          }
          values.push(applyOp(op, val2, val1));
        }
        ops.push(token);
      } else {
        throw new Error(`Invalid token: ${token}`);
      }
    }

    while (ops.length > 0) {
       const op = ops.pop();
       const val2 = values.pop();
       const val1 = values.pop();
       if (op === undefined || val1 === undefined || val2 === undefined || op === '(') {
             throw new Error("Invalid expression");
       }
       values.push(applyOp(op, val2, val1));
    }
    
    if (values.length !== 1 || ops.length > 0) {
        return 'Błąd';
    }

    const result = values[0];
    return String(parseFloat(result.toFixed(7)));

  } catch (error) {
    return 'Błąd';
  }
};
