import React, { useState, useCallback } from 'react';
import Display from './components/Display';
import ButtonGrid from './components/ButtonGrid';
import { ButtonAction } from './types';
import { evaluate } from './utils/evaluator';

const App: React.FC = () => {
    const [expression, setExpression] = useState<string>('0');
    const [isResultShown, setIsResultShown] = useState<boolean>(false);
    const [prevExpression, setPrevExpression] = useState<string>('');

    const handleButtonClick = useCallback((action: ButtonAction, value?: string) => {
        setIsResultShown(false);
        switch (action) {
            case ButtonAction.Number:
                if (value === undefined) return;
                if (isResultShown || expression === '0' || expression === 'Błąd') {
                    setExpression(value);
                } else {
                    setExpression(prev => prev + value);
                }
                break;

            case ButtonAction.Decimal:
                 if (isResultShown || expression === 'Błąd') {
                    setExpression('0.');
                    return;
                }
                // TODO: Prevent multiple decimals in one number
                setExpression(prev => prev + '.');
                break;

            case ButtonAction.Operator:
                if (value === undefined) return;
                if (expression === 'Błąd') return;
                
                if (isResultShown) {
                     setPrevExpression(expression + ` ${value} `);
                }

                // Avoid adding operator if expression is just "0"
                if (expression === '0') {
                    setExpression('0' + ` ${value} `);
                    return;
                }

                // Avoid multiple operators in a row
                const lastChar = expression.trim().slice(-1);
                if (['+', '−', '×', '÷'].includes(lastChar)) {
                    setExpression(prev => prev.trim().slice(0, -1) + `${value} `);
                } else {
                    setExpression(prev => prev + ` ${value} `);
                }
                break;

            case ButtonAction.Parenthesis:
                if (value === undefined) return;
                 if (expression === '0' || expression === 'Błąd' || isResultShown) {
                    setExpression(value);
                } else {
                    setExpression(prev => prev + value);
                }
                break;

            case ButtonAction.Calculate:
                if (expression === 'Błąd') return;
                const result = evaluate(expression);
                setPrevExpression(`${expression} =`);
                setExpression(String(result));
                setIsResultShown(true);
                break;

            case ButtonAction.AllClear:
                setExpression('0');
                setPrevExpression('');
                setIsResultShown(false);
                break;

            case ButtonAction.Backspace:
                if (expression === 'Błąd' || isResultShown) {
                    setExpression('0');
                    return;
                }
                setExpression(prev => prev.length > 1 ? prev.slice(0, -1) : '0');
                break;
        }
    }, [expression, isResultShown]);

    return (
        <div className="flex items-center justify-center min-h-screen text-white">
            <div className="w-full max-w-sm mx-auto bg-gray-800 rounded-2xl shadow-2xl p-6 border-4 border-gray-700">
                <header className="mb-6 text-center">
                    <h1 className="text-3xl font-bold text-teal-400">Matemax.app</h1>
                    <p className="text-gray-400 text-sm">React Calculator</p>
                </header>
                <Display value={expression} expression={prevExpression} />
                <ButtonGrid onButtonClick={handleButtonClick} />
            </div>
        </div>
    );
};

export default App;
