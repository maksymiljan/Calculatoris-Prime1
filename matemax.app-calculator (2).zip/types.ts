export enum Operator {
  Add = '+',
  Subtract = '−',
  Multiply = '×',
  Divide = '÷',
}

export enum ButtonAction {
  Number = 'number',
  Operator = 'operator',
  Decimal = 'decimal',
  AllClear = 'all-clear',
  Backspace = 'backspace',
  Calculate = 'calculate',
  Parenthesis = 'parenthesis',
}
